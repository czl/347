UPDATE vendors
SET default_account_number = 403
WHERE default_account_number = 400
