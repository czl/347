ALTER TABLE groups
MODIFY group_name UNIQUE;