INSERT INTO groups
VALUES (group_id_seq.NEXTVAL, 'Folk Music Association');

SELECT * FROM groups;