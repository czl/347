CONNECT ex/ex;

SELECT script_id, script
FROM scripts;