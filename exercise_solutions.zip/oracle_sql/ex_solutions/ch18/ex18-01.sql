CONNECT ex/ex;

CREATE TABLE scripts
(
  script_id     NUMBER    PRIMARY KEY,
  script        BFILE
);
/