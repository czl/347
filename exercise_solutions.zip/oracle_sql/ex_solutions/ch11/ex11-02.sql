SELECT *
FROM open_items
WHERE balance_due >= 1000
