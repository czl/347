SELECT * FROM ap.vendors;

DELETE FROM ap.vendors
  WHERE vendor_id = 1;