SELECT DISTINCT vendor_id
FROM invoices
