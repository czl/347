SELECT invoice_total
FROM invoices
WHERE vendor_id = 115
