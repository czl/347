SELECT *
FROM null_sample
WHERE invoice_total IS NULL
