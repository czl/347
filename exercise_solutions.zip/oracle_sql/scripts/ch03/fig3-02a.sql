SELECT *
FROM invoices