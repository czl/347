SELECT *
FROM null_sample
WHERE invoice_total IS NOT NULL
