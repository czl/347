SELECT invoice_number AS "Invoice Number", invoice_date AS "Date",
    invoice_total AS total
FROM invoices
