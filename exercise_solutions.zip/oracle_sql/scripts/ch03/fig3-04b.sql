SELECT invoice_number "Invoice Number", invoice_date "Date",
    invoice_total total
FROM invoices
