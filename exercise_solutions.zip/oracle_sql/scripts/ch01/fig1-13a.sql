INSERT INTO invoices
  (invoice_id, vendor_id, invoice_number, invoice_date, 
   invoice_total, terms_id, invoice_due_date)
VALUES 
  (invoice_id_seq.NEXTVAL, 12, '3289175', '18-JUL-14', 
  165, 3, '17-AUG-14')
