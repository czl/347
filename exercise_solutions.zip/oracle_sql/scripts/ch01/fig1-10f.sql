CREATE INDEX invoices_vendor_id_index
  ON invoices (vendor_id)
