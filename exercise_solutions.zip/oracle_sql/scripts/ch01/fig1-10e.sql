ALTER TABLE invoices
DROP COLUMN balance_due
