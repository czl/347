DROP INDEX invoices_vendor_id_index
