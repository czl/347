SELECT * FROM vendors_min
WHERE vendor_state = 'CA'
ORDER BY vendor_name
