SELECT * FROM invoices
WHERE invoice_number = '367447'
