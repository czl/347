ALTER TABLE invoices
ADD balance_due NUMBER(9,2)
