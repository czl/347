UPDATE invoices
SET credit_total = 0
WHERE invoice_number = '367447'
