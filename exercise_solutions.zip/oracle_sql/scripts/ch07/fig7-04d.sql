INSERT INTO color_sample
VALUES (3, DEFAULT, 'Orange')