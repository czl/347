INSERT INTO invoices
    (invoice_id, vendor_id, invoice_number, invoice_total, payment_total, 
     credit_total, terms_id, invoice_date, invoice_due_date)
VALUES
    (115, 97, '456789', 8344.50, 0, 0, 1, '01-AUG-14', '31-AUG-14')