INSERT INTO color_sample (color_id, color_name)
VALUES (2, 'Yellow')