CREATE TABLE invoices_copy AS
SELECT *
FROM invoices
