-- use the EX connection
INSERT INTO color_sample (color_id, color_number) 
VALUES (1, 606)