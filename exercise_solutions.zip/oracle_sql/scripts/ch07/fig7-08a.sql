DELETE FROM invoice_line_items
WHERE invoice_id = 100 AND invoice_sequence = 1