UPDATE invoices
SET credit_total = credit_total + 100
WHERE invoice_number = '97/522'