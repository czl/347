UPDATE invoices
SET payment_date = '21-SEP-14', 
    payment_total = 19351.18
WHERE invoice_number = '97/522'
