CONNECT system/system;

GRANT CREATE SESSION TO ar_user;
GRANT SELECT ON customers TO ar_user;
