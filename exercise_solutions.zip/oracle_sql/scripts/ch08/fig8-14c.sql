SELECT * FROM float_sample
WHERE float_value BETWEEN 0.99 AND 1.01