SELECT * FROM string_sample
ORDER BY id