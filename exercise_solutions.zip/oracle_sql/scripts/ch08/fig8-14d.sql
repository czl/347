SELECT * FROM float_sample
WHERE ROUND(float_value, 2) = 1
