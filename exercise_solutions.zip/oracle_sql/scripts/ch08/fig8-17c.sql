SELECT * FROM date_sample
WHERE start_date >= '28-FEB-06' AND start_date < '01-MAR-06'
