SELECT * FROM float_sample
WHERE float_value = 1