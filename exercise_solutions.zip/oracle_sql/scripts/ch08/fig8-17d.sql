SELECT * FROM date_sample
WHERE TRUNC(start_date) = '28-FEB-06'