SELECT * FROM string_sample
ORDER BY TO_NUMBER(id)