-- single character test
SELECT ASCII('a') FROM DUAL;
-- multiple characters test
SELECT ASCII('abc') FROM DUAL;
-- char test
SELECT CHR(97) FROM DUAL;
-- nchar tests
SELECT NCHR(97) FROM DUAL;
SELECT NCHR(332) FROM DUAL;
