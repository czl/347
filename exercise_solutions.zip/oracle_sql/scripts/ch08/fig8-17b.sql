SELECT * FROM date_sample
WHERE start_date = '28-FEB-06'
