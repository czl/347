SELECT * FROM date_sample
WHERE start_date = TO_DATE('10:00:00', 'HH24:MI:SS')
