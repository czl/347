SELECT * FROM date_sample
WHERE TO_CHAR(start_date, 'HH24:MI:SS') = '10:00:00'
