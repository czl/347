-- use the EX connection
SELECT * FROM string_sample