SELECT LPAD(id, 2, '0') AS lpad_id, name 
FROM string_sample
ORDER BY lpad_id